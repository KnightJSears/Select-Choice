import React from 'react';

function Checkout() {
    return (
        <div id="checkout"><h4>You have checked out! Thank you for shopping on our website!</h4></div>
    )
}

export default Checkout;
